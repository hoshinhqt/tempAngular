import { Directive, ElementRef, HostBinding, HostListener, Renderer2 } from '@angular/core';

@Directive({
  selector: '[appHighLight]'
})
export class HighLightDirective {

  constructor(private ele: ElementRef, private render2: Renderer2) {
    this.ele.nativeElement.style.backgroundColor = 'red';
    this.render2.setStyle(this.ele.nativeElement, 'background-color', 'red');
  }
  @HostBinding('style.backgoundColor') bgColor : string = 'aqua';

  @HostListener('mouseenter') SuKienHover(){
    this.render2.setStyle(this.ele.nativeElement, 'background-color', 'yellow');

  }
  @HostListener('mouseleave') SuKienLeave(){
    this.render2.setStyle(this.ele.nativeElement, 'background-color', 'blue');
    
  }
}
