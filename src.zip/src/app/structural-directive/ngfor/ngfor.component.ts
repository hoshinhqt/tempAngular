import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngfor',
  templateUrl: './ngfor.component.html',
  styleUrls: ['./ngfor.component.scss']
})
export class NgforComponent implements OnInit {
  danhSachNhanVien = [
    {
      ten: 'Fe42',
      tuoi :2,

    },
    {
      ten: 'fe43',
      tuoi :4,
      
    },
    {
      ten: 'Fe42',
      tuoi :4,
      
    }
  ];
  constructor() { }

  ngOnInit(): void {
  }
  
}
