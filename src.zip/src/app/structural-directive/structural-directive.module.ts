import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { StructuralDirectiveComponent } from './structural-directive.component';
import { NgIfComponent } from './ng-if/ng-if.component';
import { NgforComponent } from './ngfor/ngfor.component';
import { NgSwitchComponent } from './ng-switch/ng-switch.component';
import { BaitapNgforComponent } from './baitap-ngfor/baitap-ngfor.component';
import { NgcontentComponent } from './ngcontent/ngcontent.component';
import { ItemComponent } from './ngcontent/item/item.component';



@NgModule({
  declarations: [StructuralDirectiveComponent, NgIfComponent, NgforComponent, NgSwitchComponent, BaitapNgforComponent, NgcontentComponent, ItemComponent],
  imports: [
    CommonModule
  ],
  exports :[
    StructuralDirectiveComponent,
   
  ]
})
export class StructuralDirectiveModule { }
