import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ng-if',
  templateUrl: './ng-if.component.html',
  styleUrls: ['./ng-if.component.scss']
})
export class NgIfComponent implements OnInit {

  public status : boolean = false;
  statusLogin : boolean =  true;
  constructor() { }

  ngOnInit(): void {
  }
  show(){
    this.status = true;
    console.log(status);
    
  }
  hidden(){
    this.status = false;
  }
  Logout(){
    this.statusLogin = false;
  }
  SignIn(){
    this.statusLogin = true;
  }
}
