import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap-ngfor',
  templateUrl: './baitap-ngfor.component.html',
  styleUrls: ['./baitap-ngfor.component.scss']
})
export class BaitapNgforComponent implements OnInit {
  danhSachSanPham  = Array<any>();
  constructor() { }

  ngOnInit(): void {
  }
  themSanPham(masp: string, tensp : string, giasp: string): void{
    const objectSP  = {
      maSP : masp,
      tenSP: tensp, 
      gia: giasp
    };
    this.danhSachSanPham.push(objectSP);
  }
}
