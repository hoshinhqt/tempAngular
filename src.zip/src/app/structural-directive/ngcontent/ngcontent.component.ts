import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ngcontent',
  templateUrl: './ngcontent.component.html',
  styleUrls: ['./ngcontent.component.scss']
})
export class NgcontentComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
