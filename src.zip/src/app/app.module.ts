import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DemoBuoi1Component } from './demo-buoi1/demo-buoi1.component';
import { BaitapBuoi1Component } from './baitap-buoi1/baitap-buoi1.component';
import { HeaderBaiTap1Component } from './baitap-buoi1/header-bai-tap1/header-bai-tap1.component';
import { ContentBaiTap1Component } from './baitap-buoi1/content-bai-tap1/content-bai-tap1.component';
import { SideBarBaiTap1Component } from './baitap-buoi1/side-bar-bai-tap1/side-bar-bai-tap1.component';
import { FooterBaiTap1Component } from './baitap-buoi1/footer-bai-tap1/footer-bai-tap1.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DemoModuleModule } from './demo-module/demo-module.module';
import { DataBindingComponent } from './data-binding/data-binding.component';
import { OneWayComponent } from './data-binding/one-way/one-way.component';
import { TwowayComponent } from './data-binding/twoway/twoway.component';
import { FormsModule } from '@angular/forms';
import { StructuralDirectiveComponent } from './structural-directive/structural-directive.component';
import { StructuralDirectiveModule } from './structural-directive/structural-directive.module';
import { AttributeDirectiveModule } from './attribute-directive/attribute-directive.module';



@NgModule({
  //import component
  declarations: [
    AppComponent,
    DemoBuoi1Component,
    BaitapBuoi1Component,
    HeaderBaiTap1Component,
    ContentBaiTap1Component,
    SideBarBaiTap1Component,
    FooterBaiTap1Component,
    DataBindingComponent,
    OneWayComponent,
    TwowayComponent,
   
  ],
  //import module
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    DemoModuleModule,
    FormsModule,
    StructuralDirectiveModule,
    AttributeDirectiveModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
