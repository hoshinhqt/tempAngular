import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test-word',
  templateUrl: './test-word.component.html',
  styleUrls: ['./test-word.component.scss']
})
export class TestWordComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
