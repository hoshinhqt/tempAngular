import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { __exportStar } from 'tslib';
import { TestWordComponent } from './test-word/test-word.component';
import { DemoModuleComponent } from './demo-module.component';


// moi component chi quan ly boi duy nhat trong mot module
@NgModule({
  declarations: [
    // DemoModuleComponent,
    TestWordComponent,
    DemoModuleComponent
  ],
  imports: [
    CommonModule
  ],
  exports : [
    // DemoModuleComponent,
    TestWordComponent,
  ]
})
export class DemoModuleModule { }
