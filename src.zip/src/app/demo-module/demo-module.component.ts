import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-module',
  templateUrl: './demo-module.component.html',
  styleUrls: ['./demo-module.component.scss']
})
export class DemoModuleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
