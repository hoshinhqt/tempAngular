import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-footer-bai-tap1',
  templateUrl: './footer-bai-tap1.component.html',
  styleUrls: ['./footer-bai-tap1.component.scss']
})
export class FooterBaiTap1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
