import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FooterBaiTap1Component } from './footer-bai-tap1.component';

describe('FooterBaiTap1Component', () => {
  let component: FooterBaiTap1Component;
  let fixture: ComponentFixture<FooterBaiTap1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FooterBaiTap1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterBaiTap1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
