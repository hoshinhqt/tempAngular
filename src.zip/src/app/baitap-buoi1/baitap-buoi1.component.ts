import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-baitap-buoi1',
  templateUrl: './baitap-buoi1.component.html',
  styleUrls: ['./baitap-buoi1.component.scss']
})
export class BaitapBuoi1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
