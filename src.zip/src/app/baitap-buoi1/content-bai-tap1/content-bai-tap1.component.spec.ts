import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ContentBaiTap1Component } from './content-bai-tap1.component';

describe('ContentBaiTap1Component', () => {
  let component: ContentBaiTap1Component;
  let fixture: ComponentFixture<ContentBaiTap1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ContentBaiTap1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ContentBaiTap1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
