import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-content-bai-tap1',
  templateUrl: './content-bai-tap1.component.html',
  styleUrls: ['./content-bai-tap1.component.scss']
})
export class ContentBaiTap1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
