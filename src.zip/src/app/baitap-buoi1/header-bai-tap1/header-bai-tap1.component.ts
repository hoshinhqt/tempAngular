import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header-bai-tap1',
  templateUrl: './header-bai-tap1.component.html',
  styleUrls: ['./header-bai-tap1.component.scss']
})
export class HeaderBaiTap1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
