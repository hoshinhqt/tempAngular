import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-bar-bai-tap1',
  templateUrl: './side-bar-bai-tap1.component.html',
  styleUrls: ['./side-bar-bai-tap1.component.scss']
})
export class SideBarBaiTap1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
