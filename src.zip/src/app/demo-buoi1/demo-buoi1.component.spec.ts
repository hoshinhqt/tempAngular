import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DemoBuoi1Component } from './demo-buoi1.component';

describe('DemoBuoi1Component', () => {
  let component: DemoBuoi1Component;
  let fixture: ComponentFixture<DemoBuoi1Component>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DemoBuoi1Component ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DemoBuoi1Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
