import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-buoi1',
  templateUrl: './demo-buoi1.component.html',
  styleUrls: ['./demo-buoi1.component.scss']
})
export class DemoBuoi1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
